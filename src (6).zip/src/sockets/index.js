const { Server } = require('socket.io');
const env = require('../config/env');

let io;

function initSocket(httpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: env.clientUrl,
      credentials: true
    }
  });

  io.on('connection', (socket) => {
    console.log(`[socket] Naya connection: ${socket.id}`);

    socket.on('disconnect', () => {
      console.log(`[socket] Disconnect ho gaya: ${socket.id}`);
    });
  });

  return io;
}

function getIO() {
  if (!io) {
    throw new Error('Socket.IO abhi initialize nahi hua hai.');
  }
  return io;
}

module.exports = { initSocket, getIO };